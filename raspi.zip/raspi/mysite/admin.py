from django.contrib import admin
from mysite import models

admin.site.register(models.Subdomain)